Zillow FRBO Helper (Private/Throttled)

Quick setup
- Load unpacked: Chrome → chrome://extensions → Developer Mode → Load unpacked → select `zillow-helper-extension/`.
- Popup:
  - Backend URL: `https://zillow-assistant-backend.onrender.com`
  - Count: e.g., 10
  - Caps: set per‑hour (default 25) and per‑day (default 75)
- Options (right-click icon → Options):
  - Set your message template (variables: {address} {city} {price} {beds} {baths})
  - Keep “Skip if agent/managed” ON
  - Cooldown days: 90

Usage
- Click “Get & Open” to fetch `/api/leads/next-batch` and open tabs.
- On each Zillow tab, the message auto-fills; you click Send.
- HUD buttons:
  - Mark Sent → POST `/api/leads/mark`
  - Skip → POST `/api/leads/mark` with status `skipped`
- Hotkeys:
  - Alt+F → Re-fill message
  - Alt+N → Mark sent (backend) and proceed to next tab manually

Troubleshooting
- CORS: Backend must allow `chrome-extension://*` and `GET, POST, OPTIONS`.
- Empty batch: seed with `/api/leads/ingest` or wait for Gmail→Sheet trigger.
- No autofill: press Alt+F once; selectors are generic but Zillow changes UI often.
 - Use a dedicated Chrome Profile and enable “Allow in Incognito”. DuckDuckGo desktop cannot load Chrome extensions; use bookmarklet fallback only if necessary.


