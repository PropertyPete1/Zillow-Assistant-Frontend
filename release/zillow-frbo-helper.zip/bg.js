// Batch opener with 20–50s jitter between tabs and per-hour/day caps
const state = {
  paused: false,
  queue: [],
  opening: false,
  limits: { perHour: 25, perDay: 75 },
  counts: { hour: 0, day: 0 },
  timestamps: { hourStart: Date.now(), dayStart: Date.now() },
  break: { nextAt: Math.floor(6 + Math.random() * 5), since: 0 },
};

function jitter(minMs, maxMs) { return minMs + Math.floor(Math.random() * (maxMs - minMs + 1)); }
function resetWindows() {
  const now = Date.now();
  if (now - state.timestamps.hourStart > 3600e3) { state.timestamps.hourStart = now; state.counts.hour = 0; }
  if (now - state.timestamps.dayStart > 86400e3) { state.timestamps.dayStart = now; state.counts.day = 0; }
}

async function openNext() {
  resetWindows();
  if (state.paused || state.opening || state.queue.length === 0) return;
  if (state.counts.hour >= state.limits.perHour || state.counts.day >= state.limits.perDay) return;
  state.opening = true;
  const item = state.queue.shift();
  await chrome.tabs.create({ url: item.url, active: false });
  state.counts.hour += 1; state.counts.day += 1;
  state.break.since += 1;
  const cont = () => { state.opening = false; openNext(); };
  if (state.break.since >= state.break.nextAt) {
    // micro-break 60–180s
    state.break.since = 0; state.break.nextAt = Math.floor(6 + Math.random() * 5);
    setTimeout(cont, jitter(60000, 180000));
  } else {
    setTimeout(cont, jitter(20000, 50000));
  }
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type === 'OPEN_BATCH') {
    state.queue = msg.items || [];
    state.paused = false;
    openNext();
    sendResponse({ ok: true, queued: state.queue.length });
  } else if (msg.type === 'PAUSE') {
    state.paused = true; sendResponse({ ok: true });
  } else if (msg.type === 'RESUME') {
    state.paused = false; openNext(); sendResponse({ ok: true });
  } else if (msg.type === 'SET_LIMITS') {
    state.limits = msg.limits || state.limits; sendResponse({ ok: true, limits: state.limits });
  }
});

// Load saved limits on startup
chrome.storage.sync.get(['capHour','capDay'], (st) => {
  if (st.capHour) state.limits.perHour = Number(st.capHour);
  if (st.capDay) state.limits.perDay = Number(st.capDay);
});


