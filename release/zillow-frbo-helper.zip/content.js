(function () {
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  function textContent(qs) {
    const el = document.querySelector(qs);
    return el ? el.textContent.trim() : '';
  }

  function detectFRBO() {
    const txt = document.body.innerText.toLowerCase();
    const positive = [
      'for rent by owner',
      'listed by owner',
      'contact owner',
      'owner managed',
      'message owner',
      'landlord',
    ];
    const negative = [
      'listing agent',
      'brokered by',
      'property manager',
      'managed by',
      'real estate llc',
      'realtors®',
      'brokerage',
    ];
    const pos = positive.some((p) => txt.includes(p));
    const neg = negative.some((n) => txt.includes(n));
    if (pos && !neg) return { flag: 'true', reason: 'onpage:owner-phrases' };
    if (neg && !pos) return { flag: 'false', reason: 'onpage:agent-phrases' };
    return { flag: 'unsure', reason: 'onpage:mixed-or-missing' };
  }

  function scrapeMeta() {
    const address =
      textContent('[data-testid="home-details-summary-headline"]') ||
      textContent('h1[data-testid="bdp-building-name"]') ||
      textContent('h1');
    const price = textContent('[data-testid="price"]') || textContent('[data-testid="bdp-price"]') || '';
    const beds = textContent('[data-testid="bed-bath-beyond-beds"]') || '';
    const baths = textContent('[data-testid="bed-bath-beyond-baths"]') || '';
    return { address, price, beds, baths };
  }

  function findMessageBox() {
    const candidates = ['textarea', '[contenteditable="true"]', 'input[type="text"]'];
    for (const sel of candidates) {
      const els = Array.from(document.querySelectorAll(sel));
      for (const el of els) {
        const ph = (el.getAttribute('placeholder') || '').toLowerCase();
        const aria = (el.getAttribute('aria-label') || '').toLowerCase();
        const name = (el.getAttribute('name') || '').toLowerCase();
        const hints = [ph, aria, name, el.outerHTML.toLowerCase()].join(' ');
        if (hints.includes('message') || hints.includes('contact') || hints.includes('ask')) {
          return el;
        }
      }
    }
    const ta = Array.from(document.querySelectorAll('textarea')).sort((a, b) => b.offsetHeight - a.offsetHeight)[0];
    return ta || null;
  }

  async function fillMessage() {
    const { tpl, skipAgents } = await chrome.storage.sync.get(['tpl', 'skipAgents']);
    const meta = scrapeMeta();
    const frbo = detectFRBO();

    if (skipAgents && frbo.flag === 'false') {
      console.info('[Zillow Helper] Agent/Managed detected. Skipping autofill.');
      return { skipped: true, reason: 'agent_detected', meta, frbo };
    }

    const box = findMessageBox();
    if (!box) return { skipped: true, reason: 'no_message_box', meta, frbo };

    const msg = (tpl || '')
      .replace('{address}', meta.address || '')
      .replace('{city}', (meta.address || '').split(',')[1]?.trim() || '')
      .replace('{price}', meta.price || '')
      .replace('{beds}', meta.beds || '')
      .replace('{baths}', meta.baths || '');

    if ('value' in box) {
      box.value = msg;
      box.dispatchEvent(new Event('input', { bubbles: true }));
    } else {
      box.textContent = msg;
      box.dispatchEvent(new Event('input', { bubbles: true }));
    }

    box.focus();
    console.info('[Zillow Helper] Autofilled message.');
    makeHUD(meta, frbo);
    return { skipped: false, meta, frbo };
  }

  function makeHUD(meta, frbo) {
    if (document.getElementById('zl-hud')) return;
    const hud = document.createElement('div');
    hud.id = 'zl-hud';
    hud.style.cssText =
      'position:fixed;right:12px;bottom:12px;background:#111;color:#fff;padding:8px 10px;border-radius:8px;font:12px system-ui;z-index:999999;opacity:.92';
    const badge = frbo.flag === 'true' ? 'FRBO ✅' : frbo.flag === 'false' ? 'AGENT ❌' : 'UNSURE ⚠️';
    hud.innerHTML = `
      <div style="margin-bottom:6px">${badge} <small style="opacity:.7">(${frbo.reason})</small></div>
      <button id="zl-mark-sent">Mark Sent</button>
      <button id="zl-mark-skip" style="margin-left:6px">Skip</button>
      <style>button{background:#fff;color:#111;border:none;border-radius:6px;padding:6px 8px;cursor:pointer}</style>
    `;
    document.body.appendChild(hud);

    const mark = (status, reason) => {
      chrome.storage.sync.get(['api']).then(({ api }) => {
        const payload = {
          url: location.href.split('?')[0],
          status,
          reason,
          address: meta.address,
          price: meta.price,
        };
        if (!api) return console.warn('No backend API set in popup.');
        fetch(`${api.replace(/\/$/, '')}/api/leads/mark`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        })
          .then(() => console.info('[Zillow Helper] Marked', status))
          .catch((e) => console.warn('Mark error', e));
      });
    };
    document.getElementById('zl-mark-sent').onclick = () => {
      mark('sent');
    };
    document.getElementById('zl-mark-skip').onclick = () => {
      mark('skipped', 'manual');
    };
  }

  window.addEventListener('keydown', (e) => {
    if (e.altKey && e.key.toLowerCase() === 'f') {
      fillMessage();
    }
    if (e.altKey && e.key.toLowerCase() === 'n') {
      chrome.storage.sync.get(['api']).then(({ api }) => {
        const meta = scrapeMeta();
        if (api)
          fetch(`${api.replace(/\/$/, '')}/api/leads/mark`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              url: location.href.split('?')[0],
              status: 'sent',
              address: meta.address,
              price: meta.price,
            }),
          });
      });
    }
  });

  (async () => {
    await sleep(1200);
    await fillMessage();
  })();
})();


