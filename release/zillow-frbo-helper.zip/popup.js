const apiEl = document.getElementById('api');
const countEl = document.getElementById('count');
const outEl = document.getElementById('out');
const capHour = document.getElementById('capHour');
const capDay = document.getElementById('capDay');

(async () => {
  const st = await chrome.storage.sync.get(['api','capHour','capDay']);
  if (st.api) apiEl.value = st.api;
  if (st.capHour) capHour.value = st.capHour;
  if (st.capDay) capDay.value = st.capDay;
})();

document.getElementById('get').onclick = async () => {
  const api = apiEl.value.trim();
  await chrome.storage.sync.set({ api });
  const count = Number(countEl.value || 10);
  outEl.textContent = 'Fetching...';
  try {
    const r = await fetch(`${api.replace(/\/$/, '')}/api/leads/next-batch?count=${count}`);
    const items = await r.json();
    chrome.runtime.sendMessage({ type: 'OPEN_BATCH', items }, (resp) => {
      outEl.textContent = `Queued ${items.length} tabs.`;
    });
  } catch (e) {
    outEl.textContent = 'Error: ' + e.message;
  }
};

document.getElementById('pause').onclick = () =>
  chrome.runtime.sendMessage({ type: 'PAUSE' }, () => {
    outEl.textContent = 'Paused';
  });
document.getElementById('resume').onclick = () =>
  chrome.runtime.sendMessage({ type: 'RESUME' }, () => {
    outEl.textContent = 'Resumed';
  });

document.getElementById('saveCaps').onclick = async () => {
  const limits = { perHour: Number(capHour.value || 25), perDay: Number(capDay.value || 75) };
  await chrome.storage.sync.set({ capHour: limits.perHour, capDay: limits.perDay });
  chrome.runtime.sendMessage({ type: 'SET_LIMITS', limits }, () => {
    outEl.textContent = 'Caps saved.';
  });
};


